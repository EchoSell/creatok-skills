---
name: creatok-analyze-video
description: Analyze a TikTok video’s script, scenes, hook and creative structure. Not Shop Analytics performance reporting.
---

# CreatOK Video Analysis

## MCP tool scope

Use the connected CreatOK tools: creatok_capabilities_get, creatok_asset_upload_prepare, creatok_asset_upload_finalize, creatok_content_analyze. These are logical tool names; Codex may namespace or defer them. Use host tool discovery and invoke the matching connected tool; do not guess an identifier or call the endpoint directly.

Read and apply [`./references/user-experience.md`](./references/user-experience.md) before choices, confirmations, presentation, or handoffs.

## Non-negotiable credential boundary

Use only the connected CreatOK MCP tools above for CreatOK operations. Never use curl, Shell, PowerShell, browser requests, generic HTTP tools, direct endpoint calls, or a local CLI as fallback. Local execution is permitted only for the packaged upload helper in [local-media-upload.md](./references/local-media-upload.md). Never request or read API keys, tokens, `Authorization` headers, connector configuration, credential files, or environment variables including `CREATOK_API_KEY`; never display or transmit them. If secret-like content appears unexpectedly, suppress it, report only the stable error code and `request_id`, and tell the user to rotate the key. For `WORKSPACE_REQUIRED`, ask the user to reconnect the connector and pick an organization workspace during authorization; never ask for a credential in chat.

## CreatOK-only execution boundary

When the user explicitly asks for CreatOK or selects this connector, every CreatOK business operation must use a connected CreatOK MCP tool listed in this Skill's MCP tool scope. Never call Codex built-in ImageGen or video generation, another connector, another provider, or any host-provided generation or processing capability as a fallback. If a required CreatOK tool is missing from the current tool context or a CreatOK call fails, stop the requested operation and report the missing tool or stable MCP `code` and `request_id`. Only follow an explicit CreatOK recovery path such as same-key idempotency replay or status lookup; never continue through a non-CreatOK fallback. Use local execution only for that packaged upload helper.

Model `id` and `default_model` values are internal CreatOK tool arguments. In every user-visible model list, choice, summary, estimate, confirmation, or result, show only the model `label`; never show model identifiers.

## Analyze the reference

Call `creatok_capabilities_get` and read `processing_limits.content_analysis`. Accept a supported TikTok URL or a user-selected local video. For a local video, follow [local-media-upload.md](./references/local-media-upload.md): prepare, PUT the original file bytes, finalize, and use the returned formal `asset_uid` or `object_key`. Never use temporary keys. For a TikTok URL, pass `url`. Use exactly one source and the selected `locale`.

Call `creatok_content_analyze` with `mode=ensure` and one stable `idempotency_key`. TikTok video analysis consumes plan allowance. For a timeout, `RESULT_UNKNOWN`, or `TASK_NOT_READY` on a TikTok URL, query `mode=get` with the original URL and locale, without an idempotency key. A missing result does not prove the original operation failed; do not create a replacement key. For an Asset, retry `mode=ensure` with the original arguments and original idempotency key; do not use `get` to infer failure. Preserve diagnostic identifiers.

Read the video snapshot from `data.result` only after checking `data.media_type=video` and `data.status=completed`. Use the returned `result.visual` and available snapshot fields; do not assume legacy `video`, `transcript.segments`, or `vision.scenes` fields. If the result is another media type, incomplete, untranslated or unavailable, report its actual state and do not present it as a completed video analysis. Do not invent absent source observations.

## Present the analysis

Infer the content type to choose useful analysis: selling videos need proof, trust and conversion logic; demos need demonstration order; before/after needs contrast and payoff; reviews need credibility; entertainment needs pacing and emotional pull. Do not force a selling interpretation on non-selling content.

Show a timestamped original script and a storyboard table with time range, scene summary, visual action, and speech/on-screen text. Summarize only returned video metadata such as title and duration when available. Explain hook, pacing, proof and CTA where relevant; distinguish returned source observations from your interpretation.

Offer up to three short numbered next steps appropriate to the content. Route adaptation to `creatok-recreate-video`, carrying forward the full analysis and any known product context so the user does not have to repeat it. Do not automatically generate or optimize a prompt.

All IDs and URLs must come from MCP results. Use the serialized JSON in the first text result when structured output is unavailable. Keep diagnostic `request_id` values for recovery; never invent source data or handles.
