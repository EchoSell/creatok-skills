# Generate with reference video

Use this scenario when the user explicitly selects an existing video as a generation reference. It is distinct from character replacement and from a recreation request that also calls for analysis and adaptation.

Resolve the exact video from the user's selected attachment or organization Asset before uploading or browsing. Use the parent Skill's formal Asset import/upload flow if necessary. Read current capabilities and choose only a model that advertises reference-video input; check actual duration, media-count, combination, orientation and definition limits. Ask for a material model or media decision if the request and capabilities do not determine it; do not silently substitute first-frame mode.

Preserve the chosen prompt and ordered references. Use the parent Skill's generation workflow to estimate with the final options, show model label, reference, duration, resolution, orientation and credit cost, and obtain confirmation before submission. Submit once with a stable idempotency key, poll the returned task, and deliver successful media. Reuse the same key for recovery and never rerun generation merely to repair delivery.
