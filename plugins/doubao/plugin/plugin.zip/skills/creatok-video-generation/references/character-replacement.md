# Replace a character in a video

Use this scenario for an explicit request to replace a person or character in an existing video; do not infer it from ordinary video generation. Follow the parent Skill's CreatOK-only, credential, media selection, confirmation, and local delivery rules.

1. Resolve the exact source video and replacement character image. Both must be accessible formal organization Assets. The replacement is an image Asset, not an Avatar UID. For local files or public URLs use the parent Skill's explicit upload/import flow; never invent identifiers.
2. Read current `character_replacement` capability limits and the actual tool schemas. Preserve verified media metadata and allow the server to validate duration and dimensions.
3. Estimate through `creatok_credits_estimate` with `service: "character_replacement"` and the exact video and image Asset references. Show the visible source and replacement, relevant options and estimated credits; obtain explicit confirmation of that operation before submission.
4. Submit `creatok_character_replace` with the confirmed references and one stable idempotency key. Preserve the returned task ID, poll `creatok_task_get` until terminal, and deliver the returned video using the parent Skill's result-delivery procedure.
5. On timeout or an unknown outcome, reuse the same key and inspect the known task. Never create a second paid job merely because submission or delivery is uncertain. Report actual errors and `request_id`; do not claim completion for queued or failed tasks.
