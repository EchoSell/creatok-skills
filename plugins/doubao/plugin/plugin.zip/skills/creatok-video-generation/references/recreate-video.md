# Recreate or remix a video

Preserve the user's requested outcome: a creative plan or an actual generated video.

## Analyze the reference

Reuse suitable analysis already in the conversation. Otherwise obtain the user's supported TikTok post URL or an accessible formal organization video Asset. For an explicit local video, use `creatok-assets` to upload it and continue with its formal Asset UID. Ask for a missing reference; never invent one. Analysis is part of a recreation request and does not require a separate user request.

Call `creatok_capabilities_get` for current limits and `creatok_content_analyze` with exactly one source, `mode: "ensure"`, the desired locale and a stable `idempotency_key`. Inspect `media_type`, `status` and `result`; a post may be a video, image or carousel. Respect `needs_translation`, `incomplete` and `not_requested`, and do not invent missing scenes or speech. Allow at least 310 seconds. After an unknown result for a TikTok URL, query `mode: "get"` with the same source and locale, but omit `idempotency_key`: read-only lookup does not accept it. If the lookup returns `not_requested` while the original request may still be processing, wait and query again rather than immediately submitting a new analysis. For an Asset, replay the same ensure request with the same key. Do not treat Asset `get` as saved analysis.

## Adapt and deliver

Reuse known product, audience, platform and creative constraints; ask only for blocking information. Develop a differentiated script, storyboard, visual direction and practical shot plan grounded in the source and brief. Separate observations from interpretation and make clear what changes. Do not call retired prompt-optimization or video-analysis tools.

If the user requested a video, carry the script, product facts, assets and segment plan into the parent generation workflow, including capability checks, estimate, confirmation, submission, polling and delivery. If only a plan was requested, do not generate. Explain multiple-clip constraints and preserve task IDs for recovery.
