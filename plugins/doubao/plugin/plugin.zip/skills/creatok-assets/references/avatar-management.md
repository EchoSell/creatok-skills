# Avatar management

This is a scenario within `creatok-assets`, not a separate Skill. Apply its credential, upload, presentation, and recovery boundaries. Call `creatok_capabilities_get` and use current Avatar media composition, supported formats, quotas, extra-slot rules, and model readiness rather than inventing limits.

## Find and inspect

Use `creatok_avatars_list` and `creatok_avatar_get`. Present a numbered list of visible names and descriptions, wait for an exact choice, then fetch fresh detail and present its image/video/audio media as a separate numbered selection. Do not silently choose an Avatar or nested item. Keep internal identifiers and provider registration state private. In Chinese use `数字人`, `数字人素材`, and `参考图素材`.

## Create and register

Resolve the name, optional description, source, and exact media before creation. Accept explicitly selected formal organization Assets, or import/upload an explicitly selected file using the parent Skill's asset flow and its packaged upload helper. Never pass a local path as an Asset UID; local staged audio is unsupported. Follow the current composition and quota rules.

Call `creatok_avatar_create` with a stable idempotency key. If an extra slot has a charge, show the exact cost and obtain explicit confirmation before confirming that charge; a generation confirmation is not permission to buy a slot. Report success only after the tool confirms it.

Register with `creatok_avatar_register` only when the chosen video model and Avatar media require it. Once the user has chosen both, treat registration as preparation, use one stable idempotency key, and query the Avatar until ready. Do not claim readiness until the returned model status confirms it. On timeout or unknown result, keep the key and inspect state before retrying.

## Delete

Resolve the exact Avatar or nested media item from current visible choices. Inspect current delete modes: Avatar deletion is permanent-only, not ordinary Asset recycle. Explain the exact target and irreversible effect and require explicit confirmation before the permanent-delete call. Respect returned storage-release semantics and never choose another target on failure. For `RESULT_UNKNOWN`, reuse the same key and inspect the exact Avatar state before further mutation.
