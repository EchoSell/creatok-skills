---
name: creatok-image-generation
description: Create and enhance images, product image sets, multi-angle product views, and image recreations with CreatOK.
category: media
version: 0.1.0
author: CreatOK
metadata:
  display_name: CreatOK 图片生成
  display_description: 制作商品套图、多角度图和图片复刻，支持图片生成与高清处理。
  icon: ./assets/icon.png
allowed-tools: creatok_capabilities_get, creatok_credits_estimate, creatok_asset_import_from_url, creatok_asset_upload_prepare, creatok_asset_upload_finalize, creatok_image_generate, creatok_image_upscale, creatok_task_get
---

# CreatOK 图片生成

Use this Skill for image generation, image upscaling and the image business workflows below. Read and apply [`./references/user-experience.md`](./references/user-experience.md) before asking for choices, confirming credits, or presenting results. Resolve explicitly selected local media using [`./references/local-media-upload.md`](./references/local-media-upload.md).

## Business workflow routing

Read only the relevant reference. If the user asks only for a plan, deliver the plan without generating. If they ask for finished images, continue through estimation, confirmation, generation and delivery; do not stop at prompts.

- Product listing image sets and coherent product visuals: [`./references/product-image-set.md`](./references/product-image-set.md).
- Multiple product viewpoints, including when part of a larger set: [`./references/multi-angle-product.md`](./references/multi-angle-product.md).
- Adapting one or more reference images to the user's product: [`./references/image-recreation.md`](./references/image-recreation.md).

Separate product identity, style/layout references, and user-confirmed facts. Do not invent product claims or hidden physical details. Resolve the exact images and their roles before generation. For each output, preserve the relevant product references, present the intended settings and total cost, and follow the normal confirmation and recovery flow. If the platform cannot inspect an image, resolve a link, or accept all required references, explain the limitation and offer a supported alternative; do not claim the unavailable step succeeded.

For model and input handling for generation or upscaling, read [`./references/direct-media-tools.md`](./references/direct-media-tools.md).

## Non-negotiable credential boundary

Use only the connected CreatOK MCP tools listed above. Never call a direct HTTP endpoint, use a local CLI as a fallback, or inspect connector credentials. Never request, display, transmit, or validate API keys, tokens, `Authorization` headers, or connector configuration. If secret-like content appears, suppress it and report only the stable error code and `request_id`. For `WORKSPACE_REQUIRED`, ask the user to reconnect and select an organization workspace.

## Image generation flow

1. Call `creatok_capabilities_get` and use the returned image capabilities and limits. Do not invent model names, aspect ratios, sizes, batch limits, or credit prices.
2. Resolve the requested image purpose, prompt, aspect ratio, size, number of outputs, and any selected reference assets. Do not treat an attached file as selected until the user explicitly identifies it as the input.
3. If an image reference is needed, use the formal Asset import/upload flow. Local upload is allowed only through the packaged helper and the exact short-lived URL returned by `creatok_asset_upload_prepare`; never use arbitrary shell HTTP.
4. Preserve the user's product facts and creative constraints; do not call retired prompt-optimization tools.
5. Before every paid generation or upscale, use `creatok_credits_estimate` for the actual selected parameters and quantity, show the per-item and total amount, and wait for explicit confirmation. Do not infer confirmation from the original creative request. If estimation fails, do not submit a paid task; if cost-affecting parameters change, estimate again and obtain confirmation for the changed task.
6. Submit with one stable idempotency key. After timeout or `RESULT_UNKNOWN`, follow the same-key recovery path and use `creatok_task_get` rather than starting a duplicate task.
7. Deliver only the exact result URLs returned by CreatOK. Never construct result URLs or add authentication headers.

Image generation is separate from video generation. Do not silently route an image request to a video model or another provider.
