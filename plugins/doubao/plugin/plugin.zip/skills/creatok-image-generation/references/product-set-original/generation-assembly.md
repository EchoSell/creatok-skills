# Generation assembly — exact project prompt transformations

Only apply when the user requests actual generation. Preserve templates and ordering; tool argument names depend on the available tool schema.

```typescript
const FIXED_RATIO_PATTERNS: RegExp[] = [
  /\b(?:1:1|16:9|9:16|4:3|3:4|2:3|3:2|21:9|5:4|4:5)\s*(?:square|vertical|portrait|horizontal|landscape)?\s*/gi,
  /\b(?:square|vertical|portrait|horizontal|landscape)\s+(?:format|aspect ratio|canvas|composition)\b/gi,
  /\b(?:in|with|as)\s+(?:a\s+)?(?:square|vertical|portrait|horizontal|landscape)\s+(?:format|aspect ratio|canvas|composition)\b/gi,
]

const META_LABEL_PATTERNS: RegExp[] = [
  /\b(?:module\s+role|role|composition|prompt|style\s+bible|layout)\s*:\s*/gi,
]

const RATIO_LABELS: Record<string, string> = {
  "1:1":
    "Adapt the layout for a balanced square canvas: centered visual hierarchy, even margins, compact text groups, and no cropped product edges.",
  "9:16":
    "Adapt the layout for a tall portrait canvas: stack the headline, product, and proof blocks vertically with generous top and bottom safe margins.",
  "3:4":
    "Adapt the layout for a portrait canvas: use vertical information flow, keep callouts close to the product, and leave safe space around all text.",
  "4:5":
    "Adapt the layout for a social portrait canvas: strong top headline, product in the visual center, and readable benefit blocks below or beside it.",
  "16:9":
    "Adapt the layout for a wide landscape canvas: use horizontal visual flow, place the product and copy in balanced zones, and avoid tall stacked text.",
  "4:3":
    "Adapt the layout for a landscape canvas: use a wide editorial composition with clear left-to-right hierarchy and safe side margins.",
  "3:2":
    "Adapt the layout for a classic landscape canvas: keep the product dominant, distribute callouts across the width, and preserve clean whitespace.",
}

export function stripFixedAspectRatioPhrases(prompt: string): string {
  let cleaned = prompt
  for (const pattern of FIXED_RATIO_PATTERNS) {
    cleaned = cleaned.replace(pattern, "")
  }
  return cleaned
    .replace(/\s{2,}/g, " ")
    .replace(/\s+([,.])/g, "$1")
    .trim()
}

export function cleanImagePromptForGeneration(prompt: string): string {
  let cleaned = stripFixedAspectRatioPhrases(prompt)
  for (const pattern of META_LABEL_PATTERNS) {
    cleaned = cleaned.replace(pattern, "")
  }
  return cleaned
    .replace(/\s{2,}/g, " ")
    .replace(/\s+([,.])/g, "$1")
    .trim()
}

export function appendAspectRatioPromptHint(prompt: string, aspect_ratio?: string): string {
  const cleaned = cleanImagePromptForGeneration(prompt)
  if (!aspect_ratio) return cleaned

  if (
    /pure-white-product-main-image|pure white product main image|absolute pure white/i.test(cleaned)
  ) {
    return `${cleaned} Fit this pure-white product main image into the selected ${aspect_ratio} canvas while keeping the product centered, fully visible, and surrounded only by pure RGB(255,255,255) white pixels except for the product itself.`.trim()
  }

  const hint =
    RATIO_LABELS[aspect_ratio] ||
    `Adapt the layout for the selected ${aspect_ratio} canvas with safe margins, readable text, flexible spacing, and no cropped product edges.`

  return `${cleaned} ${hint}`.trim()
}
const CONSISTENCY_SUFFIX =
  " Preserve the exact product identity from the reference product image: appearance, shape, colors, materials, texture, logo, label, packaging, and all key visual details. Do not alter, omit, or reinterpret any element from the original product. Do not copy the exact camera angle, crop, placement, or composition from the reference image; create a fresh e-commerce composition with moderate variation while keeping the product faithful."

function appendViewGuard(
  prompt: string,
  item: { id: string; type?: string; title?: string },
): string {
  const role = item.type || item.title || item.id
  const guard = `Product consistency has priority over angle variation: preserve the exact product identity, silhouette, proportions, structure, colors, materials, texture, logo, labels, packaging, and all distinctive parts from the uploaded product images. Choose the camera angle, crop, scale, and placement that best fit this listing image role (${role}), but only vary the view in ways that keep those product details unchanged. Keep the product size and placement commercially reasonable: the product should have a believable real-world scale, stay fully readable for its role, sit naturally on the surface or inside the layout, avoid floating unless the role explicitly calls for a clean cutout, avoid awkward cropping, and leave enough safe margin around the product and any surrounding elements. Avoid repeating the exact reference-image angle or the same view used by the other images when a more natural role-appropriate view can still preserve the product accurately.`
  return `${prompt} ${guard}`.trim()
}

function appendNoCopyLayoutGuard(prompt: string, copyLanguage?: string): string {
  if (copyLanguage !== "none") return prompt
  return `${prompt} No added text or typography. Redesign this as a text-free commercial product image, not a copy-heavy infographic with the words removed. Do not leave blank headline areas, empty label boxes, empty badges, empty data tables, empty callout shells, or connector lines that imply missing text; use product photography, props, lighting, material texture, negative space, and visual composition instead.`.trim()
}

function buildItem(
  p: { id: string; prompt: string; type?: string; title?: string },
  common: {
    imageUrls: string[]
    resolution: string
    aspect_ratio?: string
    isAspectSupported: boolean
    copyLanguage?: string
  },
) {
  const prompt = appendNoCopyLayoutGuard(
    appendViewGuard(appendAspectRatioPromptHint(p.prompt, common.aspect_ratio), p),
    common.copyLanguage,
  )

  return {
    id: p.id,
    prompt: common.imageUrls.length > 0 ? `${prompt}${CONSISTENCY_SUFFIX}` : prompt,
    ...(common.imageUrls.length > 0 && { image_urls: common.imageUrls }),
    resolution: common.resolution,
    ...(common.aspect_ratio && common.isAspectSupported && { aspect_ratio: common.aspect_ratio }),
  }
}


```
