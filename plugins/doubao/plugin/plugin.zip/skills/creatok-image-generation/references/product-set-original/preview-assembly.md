# Preview assembly — exact project functions and user template

Evaluate template branches with the current inputs; retain the English prompt wording. Do not emit TypeScript wrappers.

```typescript
function isNoCopyMode(copyLanguage: string): boolean {
  return copyLanguage === "none"
}

function buildCopyInstruction(copyLanguage: string): string {
  if (isNoCopyMode(copyLanguage)) {
    return `NO ADDED TEXT. Do not add any readable marketing copy, headline, subhead, label text, badge text, callout text, data chip text, table text, caption, or typography. Preserve only text already printed on the product itself; do not modify, translate, remove, or invent product markings. Redesign the layout for a text-free image instead of keeping a copy-heavy infographic shell. Do not leave empty headline spaces, blank labels, empty badges, empty tables, blank callout boxes, or connector lines pointing to missing text. Communicate selling points with product photography, composition, product angles, lighting, props, materials, clean negative space, and scene design.`
  }

  const languageLabel = getLanguageOption(copyLanguage)?.aiPrompt ?? copyLanguage
  return `Copy is allowed. Visible text should use: ${languageLabel}. Use short real copy, never placeholders.`
}

function buildNoCopyPromptGuard(noCopyMode: boolean): string {
  return noCopyMode
    ? " No added text or typography. Do not add readable marketing copy, headline, subhead, labels, badges, callout text, table text, captions, watermarks, or fake microcopy. Preserve only text already printed on the product itself. Redesign the composition for no-copy output; do not keep blank text areas, empty label boxes, empty badges, empty data tables, empty callout shells, or connector lines that imply missing text."
    : ""
}

function appendPreviewPromptGuards(preview: PreviewItem, prompt: string, noCopyMode: boolean) {
  const viewGuard = `Product consistency has priority over angle variation: preserve the exact product identity, silhouette, proportions, structure, colors, materials, texture, logo, labels, packaging, and all distinctive parts from the uploaded product images. Choose the camera angle, crop, scale, and placement that best fit this image role (${preview.type || preview.title || preview.id}), but only vary the view in ways that keep those product details unchanged. Keep the product size and placement commercially reasonable: the product should have a believable real-world scale, stay fully readable for its role, sit naturally on the surface or inside the layout, avoid floating unless the role explicitly calls for a clean cutout, avoid awkward cropping, and leave enough safe margin around the product and any surrounding elements. Avoid reusing the exact reference-image camera angle, crop, placement, or composition when another natural role-appropriate view can still preserve the product accurately. Across the full set, let the views feel intentionally varied rather than repeated.`

  return `${prompt} ${viewGuard}${buildNoCopyPromptGuard(noCopyMode)}`.trim()
}


function buildStyleSection(params: {
  selectedStyle?: { title: string; description: string; styleBible?: string } | null
  hasReferenceImages: boolean
  referenceStyleAnalysis?: string
  designRequirements?: string | null
  customStructure?: boolean
}): string {
  const {
    selectedStyle,
    hasReferenceImages,
    referenceStyleAnalysis,
    designRequirements,
    customStructure,
  } = params

  if (selectedStyle) {
    return `Selected global visual style: ${selectedStyle.title}
UI summary: ${selectedStyle.description}
Full Style Bible to follow across creative images 2-8:
${selectedStyle.styleBible || selectedStyle.description}

Apply this Style Bible as the full-set visual baseline for the entire requested set: palette, typography, component language, product cutout treatment, lighting, layout density, icon style, text hierarchy, and brand mood.${customStructure ? " Do not inject a default product main image unless the custom structure explicitly requests one." : " Image 1 must remain a neutral pure-white product main image."}`
  }

  if (hasReferenceImages) {
    return `Reference images are attached.
Reference image style analysis:
${referenceStyleAnalysis || "Not specified"}

Use this analysis only to extract design language: layout structure, typography style, information density, card shapes, icon style, shadow treatment, palette direction, and overall mood.
Do not copy any reference brand name, logo, product identity, exact text, exact product angle, exact product placement, crop, camera distance, or layout coordinates.
Create fresh product compositions with medium variation: preserve the user's product identity and key details, but vary product angle, crop, placement, background treatment, and visual density across the set.
Product color and user design requirements have higher priority than reference colors.
Design requirements: ${designRequirements || "-"}`
  }

  return `Custom style direction.
Infer a premium category-appropriate Style Bible from the product and buyer context.
Design requirements: ${designRequirements || "-"}`
}

function buildStructureInstruction(
  imageSetStructure: GeneratePreviewRequest["imageSetStructure"],
): string {
  if (!imageSetStructure?.items?.length) {
    return `Important: generate preview id "1" first as a pure-white product main image with no added typography, no props, no badges, and no decorative elements. Then generate the original seven creative listing previews as ids "2" through "8" with the selected Style Bible. Return numbered plain-text preview sections only, never JSON or a code block.`
  }

  const normalizedItems = imageSetStructure.items
    .map((item) => ({
      ...item,
      count: Math.max(0, Math.floor(Number(item.count) || 0)),
    }))
    .filter((item) => item.count > 0)

  if (normalizedItems.length === 0) {
    return `Important: generate preview id "1" first as a pure-white product main image with no added typography, no props, no badges, and no decorative elements. Then generate the original seven creative listing previews as ids "2" through "8" with the selected Style Bible. Return numbered plain-text preview sections only, never JSON or a code block.`
  }

  const totalCount = normalizedItems.reduce((total, item) => total + item.count, 0)
  const whiteBackgroundCount = normalizedItems
    .filter((item) => item.type === "white_background")
    .reduce((total, item) => total + item.count, 0)
  const structureLines = normalizedItems
    .map(
      (item) =>
        `- ${item.title} (${item.type}): ${item.count} image(s). Purpose: ${item.description}`,
    )
    .join("\n")

  return `Custom image set structure is required. Generate exactly ${totalCount} previews total, using sequential string ids "1" through "${totalCount}".
Allocate the preview count exactly as follows:
${structureLines}

For white-background/main-image items, use pure-white product main image treatment with no added typography, no props, no badges, and no decorative elements.
For all other items, follow the selected Style Bible and create distinct listing-ready compositions for their requested type.
${whiteBackgroundCount === 0 ? 'The custom structure requests ZERO white-background or product-main images. Do not generate any pure-white hero, clean main image, white-background cutout, marketplace main image, or "主图" style preview in any slot.' : ""}
Do not add extra previews beyond this structure. Return numbered plain-text preview sections only, never JSON or a code block.`
}


async function analyzeReferenceStyleImages(params: {
  imageUrls: string[]
  locale: string
  designRequirements?: string | null
}): Promise<string> {
  const { imageUrls, locale, designRequirements } = params
  if (imageUrls.length === 0) return ""

  const systemPrompt = `You are a senior e-commerce visual systems analyst.
Analyze the attached reference images and extract reusable design-language facts for product listing image prompt generation.

Focus on reusable design language: layout structure, typography style, information density, card/panel shapes, icon/callout style, background treatment, palette direction, lighting, shadows, and commercial mood.
Do not copy brand names, logos, exact text, watermarks, product identity, exact product angle, exact product placement, crop, camera distance, or layout coordinates from the references.
Use locale ${locale}. Return concise plain text only.`

  const userPrompt = `Analyze these reference images as a reusable style direction for a product listing image set.
User design requirements: ${designRequirements || "Not specified"}`

  const response = await llm
    .generateText({
      maxOutputTokens: AI_DEFAULT_MAX_TOKENS,
      scope: LlmScope.FRONTEND_TEXT_GENERATION,
      settingsProfile: "standard",
      prompt: userPrompt,
      system: systemPrompt,
      model: VISION_LLM_MODEL_ECONOMY,
      images: imageUrls,
      temperature: 0.25,
      thinking: DISABLED_THINKING,
    })
    .catch((error) => {
      console.warn("[ImageProductSet] reference style vision analysis failed:", error)
      return null
    })
  if (!response) return ""

  const text = response.text

  try {
    const parsed = JSON.parse(text) as { content?: unknown }
    if (typeof parsed.content === "string") return parsed.content.trim()
  } catch {
    // raw text is already the model output.
  }

  return text.trim()
}


    const userPrompt = `Create a complete product listing image set from the following inputs:
- Product information and selling points: ${sellingPoints}
- Target channel: ${platformLabel}
- Target market: ${marketLabel}
- Visible copy policy: ${copyInstruction}
- Final aspect ratio will be selected later by generation parameters. Do not include fixed aspect ratio phrases such as "1:1 square", "16:9", "9:16", "portrait canvas", or "landscape canvas" inside the prompts. Make every layout adaptable with safe margins and flexible spacing.
- Style direction:
${styleSection}
- Product variation policy: Preserve the exact product identity, shape, color, material, texture, logo, packaging, and key details from the uploaded product images, but do not reuse the exact camera angle, crop, placement, or composition. Across creative images, vary product angle, crop, placement, layout density, background treatment, and scene rhythm with medium variation.

${structureInstruction}`


```
