# CreatOK Prompt Source Map

Sync date: 2026-09-12. Source root: E:/EchoSell/creatok.

| Local resource | Project source and content |
| --- | --- |
| listing-copy.md / listing-no-copy.md / custom-copy.md / custom-no-copy.md | buildProductSetSystemPrompt in lib/image-product-set/prompt-skill.ts, expanded for the four noCopy/customStructure combinations, with locale retained as {{locale}} for runtime substitution |
| product-analysis.md | Original buildSellingPointsSystemPrompt function and visual-analysis system string from lib/image-product-set/product-brief-analysis.ts |
| style-analysis.md | Original buildStyleAnalysisSystemPrompt and buildReferenceStyleSystemPrompt functions from app/app/api/ai-tasks/image-product-set/style-analyze/route.ts |
| preview-assembly.md | Original copy branches, preview guards, style branches, custom structure, style-image analysis, and userPrompt template from app/app/api/ai-tasks/image-product-set/generate-preview/route.ts |
| generation-assembly.md | Original lib/image-product-set/aspect-ratio-prompt.ts; original CONSISTENCY_SUFFIX, appendViewGuard, appendNoCopyLayoutGuard, and buildItem from lib/services/image-generation/adapters/product-set.ts |

The four system-prompt bodies were checked verbatim against the project functions' expanded results, ignoring trailing file newlines. Supporting references preserve the source functions or templates without semantic rewriting. TypeScript wrappers express the original branches and string interpolation; they do not require backend execution.

The local entry point handles only stage routing, file-input mapping, and tool handoffs. The project's database, signed URLs, billing, network requests, model orchestration, and UI were not ported. Prompt alignment does not prove equal image quality or pixel specifications across generation tools. No comparative image-generation experiment was performed for this port.

Previously added platform-role tables, fixed 1024×1024 dimensions, a default 1:1 ratio, rewritten consistency guards, custom four-part output, and extra retries have all been removed. No other shoppable-carousel skill is used as a source.
