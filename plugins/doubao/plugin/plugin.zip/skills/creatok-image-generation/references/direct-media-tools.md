# Direct media MCP tools

These operations have no standalone Skills. Apply [execution.md](./execution.md) for the common upload → estimate/confirm → submit → status → delivery sequence where applicable, and [user-experience.md](./user-experience.md) for presentation. Read current capabilities and tool schemas rather than imposing fixed limits.

| User intent | Tool | Estimate service |
|---|---|---|
| Generate images | `creatok_image_generate` | `image_generation` |
| Upscale images | `creatok_image_upscale` | `image_upscale` |

## Inputs and options

Resolve exact source media before browsing or importing. Honor an explicitly selected attachment/Asset; otherwise resolve upload versus library and the required selections without defaulting to AI generations. Image generation needs no media selection when text-only. Image upscale supports a batch of selected image Assets up to current capabilities: never impose a single-image restriction. Video processing uses the exact source allowed by its schema. Use formal returned Asset UIDs, not local paths or object keys.

For image generation, read `models.image.models`: `limits.max_prompt_length` (Unicode code points), reference limits, output count, resolution, ratio and quality. When the user supplies an explicit final prompt, preserve it verbatim; do not rewrite or optimize it automatically. When the user instead requests a business outcome or approves a plan, formulate the necessary per-image prompts from the agreed inputs and the relevant workflow. Confirm the model label, exact prompt, references and normalized output settings.

For image upscale, use current batch size, scale, enhancement model, output format and face enhancement options. Show the selected image set and full estimated batch cost. Do not grade image quality or decide whether the requested operation is worthwhile.

