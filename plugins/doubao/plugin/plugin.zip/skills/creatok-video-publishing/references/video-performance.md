# Video performance and content review

Use this scenario for read-only video metrics and review requests. Discover the actor-visible TikTok connection, then use the current tool schemas and capability restrictions. Resolve the requested account, video or aggregate scope, and applicable time range without publishing or changing Showcase.

- Seller shop: `creatok_tiktok_shop_videos_list` finds videos; `creatok_tiktok_shop_video_get` returns a specific video's sales and engagement; `creatok_tiktok_shop_videos_overview_get` returns aggregate video-channel performance.
- Eligible US Creator account: `creatok_tiktok_creator_video_get` returns one video's daily performance with an explicit date range and required Creator performance scope.
- Supported published Shop content review: `creatok_tiktok_content_review_get` can include product attribution and comparable posts.

These routes have different account, region, and scope requirements; do not substitute Seller metrics for Creator metrics. Preserve returned pagination cursors, date semantics and stale/refresh warnings. Missing metrics are unknown, not zero. Never invent an unsupported metric, publish content, mutate Showcase, or initiate generation as part of a metrics query.
