# WorkBuddy 反馈接入验收

- 对照服务端注册表及 `FeedbackSubmitInputSchema`：`message` 和 `client` 必填，`client` 含 `cli_version`、`channel`、`os`、`arch`、`skills_hash` 五个字符串；成功返回 `feedback_id` 与 `received`。WorkBuddy 能否可靠提供 CLI 专属字段尚未验证，缺失时不能编造，可能需要服务端提供非 CLI 客户端契约。
- TDD：新增 Skill 规则断言；先对提交前版本运行并失败，再补充规则，当前工作区 `npm test` 通过。此类断言验证文档内容，不能替代客户端行为测试。
- 服务端本地模拟测试：`tests/mcp-feedback-service.test.ts` 的 5 项测试通过，覆盖成功、限流、写入失败及诊断过大；其写入依赖为模拟对象，并非真实端到端调用。
- 本地 schema 探测：`cli_version` 和 `skills_hash` 使用空字符串时当前 schema 接受；这只证明静态参数校验，不证明部署服务契约支持以空字符串表示不适用，或代表 WorkBuddy 来源标识正确。服务端目前将记录标记为 CLI，需明确跨客户端语义。
- WorkBuddy 测试环境：重新授权后，新会话确认反馈工具和 schema 可用。空 `message` 被 WorkBuddy 的 schema 校验拦截，未到服务端且无 request ID。用户明确授权一次测试记录后，以 `message=WorkBuddy E2E test`、`channel=workbuddy`、实际 `os=darwin` / `arch=arm64` 和空 `cli_version` / `skills_hash` 调用一次，不附诊断；返回 `received=true`、`feedback_id=reczz28YDYPiZcFm`、`request_id=mcp_req_9cb265b1-279e-4d5b-bdcb-d0eee319bce4`。客户端没有核实落表位置；工具正常返回代表服务端确认接收。
- 范围：测试显式要求读取临时 Skill 并调用工具，未验证安装包自动加载或自然语言路由；限流与写入失败只覆盖本地模拟，未在真实环境触发。服务端仍将 WorkBuddy 反馈标为 CLI，需服务端完善跨客户端语义。
- OAuth：重新授权后 MCP 管理界面显示绿色连接及 75/75 工具已启用。服务端 `lib/auth.ts` 配置 MCP access token 有效期 3600 秒；该配置本身不能说明 refresh token 是否发放、持久化或被 WorkBuddy 使用，401 的原因有待续查。
