# WorkBuddy 视频分析迁移验收

测试时间：2026-11-10；基础版本 `2aaa030`，包含未提交的超时与复刻事实约束修复。通过 WorkBuddy 自定义 MCP `creatok-e2e-test`，地址 `https://test.creatok.ai/api/mcp`；客户端显示 75/75 工具已启用。测试中明确读取待测 Skill 文件，尚未验证 Skill 安装包的自动加载。

| 场景 | 结果与证据 |
|---|---|
| 能力发现 | 通过：统一分析、正式 Asset 和 310 秒超时，`mcp_req_79c2d69a-7e4d-4aa5-962b-4793230960cd`。 |
| 超时配置 | TDD：300 秒时新增断言失败；修复为 310 秒后通过。未验证 WorkBuddy 实际执行时的超时上限。 |
| TikTok URL | 通过：公开样本 `https://www.tiktok.com/@sylvester6668/video/7643673311775345934`，`ensure` 返回 `video/completed`，`mcp_req_e85dc482-b32a-4c47-95bf-2767fc730d1d`。 |
| 本地视频 | 通过：5 秒合成样本经 Asset prepare、原字节 PUT、finalize、`ensure` 返回 `video/completed`，分析请求 `mcp_req_5997c3c3-ae0b-4a00-ac62-4f0fd41235e6`。 |
| 复刻 | 复用了上一轮分析且未新增 MCP 调用，但首次生成虚构商品尺寸和性能，失败；加强 Skill 后在新会话重测，数值使用待确认占位，仍需注意脚本假设商品形态。 |
| TikTok 原来源查询 | 已完成结果以同 URL、语言 `mode=get` 取回 `video/completed`，`mcp_req_31c67984-771f-4711-837b-2f31c5816b66`。这是成功结果的只读查询，不是实际未知结果故障注入。 |
| Asset 同键重放 | 原参数及原幂等键 `ensure` 返回同一结果 revision，`mcp_req_9c732724-f903-4d33-b0ff-a1c196a4d42c`。这是已完成结果重放，不是实际未知结果故障注入。 |
| RESULT_UNKNOWN / TASK_NOT_READY | 未覆盖：未注入真实受控故障，不能将成功查询或重放等同故障恢复通过。 |
| 非视频及非完成状态 | 未覆盖。 |
| 口播转写 | 未覆盖：两个样本都没有口播。 |

WorkBuddy 两次提示 deferred tools index 初次未找到工具，重新发现后调用成功；根因仍待确认。Skill 的提示约束无法保证模型绝不虚构，复刻输出仍需结合商品事实复核。`npm test` 通过只证明静态与辅助组件，不代替真实故障注入。
