# WorkBuddy TikTok 发布迁移验收

- TDD：新增发布发现及任务恢复断言，旧版本缺少新增工具权限而失败；加入工作流指令后通过。`npm test` 通过。断言只检查文档，不能证明模型或 MCP 的运行时行为。
- 测试环境：重新认证后，WorkBuddy 成功调用发布能力目录和 TikTok 连接列表；该组织返回空连接列表，无法验证账号级流程。此前工具发现失败发生在认证过期后，客户端日志显示没有可用 refresh token；原因仍待调查。
- 生产环境只读检查：重连 CreatOK 后，发布能力、连接列表、Creator 信息、发布任务历史和热门话题查询成功。唯一 Content Posting 账号 `tinypigger` 的连接 health 为 `ready`，但 grant 为 `token_invalid`；Creator 信息仍可读取，故不能推断真实发布必然成功或失败。热门音乐查询返回 `INVALID_ARGUMENT`，因为该工具要求 Shop 连接；当前工作区无 Shop 连接。
- 生产真实发布：经用户授权，使用已有视频、`tinypigger`、`DIRECT_POST` 和 `SELF_ONLY` 创建 job `966164`，状态最终为 `succeeded` / `PUBLISH_COMPLETE`；按幂等键查询得到相同任务，历史列表亦包含该任务。发布前 grant 已变为 `ready`。没有返回平台内容 ID 或 URL，因此未能核验 Creator 视频详情。
- 契约差异：Content Posting 首次调用因缺少 `provider_options.disable_comment`、`disable_duet`、`disable_stitch`、`brand_organic_toggle` 返回 `INVALID_ARGUMENT`（request_id `mcp_req_f82dd1fe-b224-44f2-abfc-345bb20d7c50`）；这些字段在工具 schema 中标为可选，服务端却要求布尔值。补齐后用原幂等键成功；Skill 已加入兼容指引，服务端应统一 schema 和校验。
- 尚未验证：其余新增工具的实际响应、Shop 媒体准备、封面准备、橱窗同步和取消任务；当前无 Shop 连接。未生成素材，也未取消或修改现有任务。
- 提交状态：发布阶段尚未完成客户端验收，改动未提交；先前 Doubao 镜像同步只为本仓库校验，并不代表发布 Doubao 包。
