# WorkBuddy 视频生成迁移验收

2026-11-10，`creatok-e2e-test` 指向测试 MCP。通过显式读取待测 Skill 文件进行验证，未验证安装包自动加载。

- TDD：旧版仍依赖 `creatok_video_prepare`，新回归断言失败；更改后断言通过。服务端 `video_generation` 估价要求完整 `prompt`、`model`、`seconds`、`definition`，返回规范化 `options`。
- 首轮实际文生视频估价：能力查询和估价成功，界面展示价格、参数及确认提示，没有提交生成；但 WorkBuddy 仍调用了 `creatok_video_prepare`（`mcp_req_bcad491e-0f7b-4b76-874a-339ea97d6cc9`），因此迁移验收失败。估价请求 `mcp_req_ac48b5c3-9063-43f5-9b32-672bc26b9522`。
- 针对实际失败先增加失败断言，再在 Skill 中明确禁止调用该旧工具，即使 capabilities 仍列出它。新会话真实重测通过：仅调用 `creatok_capabilities_get`（`mcp_req_fca317b2-6627-49d8-95b5-8d8d3c1fb8b0`）和 `creatok_credits_estimate`（`mcp_req_ec0aa478-cbf1-4c8c-94ae-c91b2ed2c832`），未调用旧工具或生成提交；展示价格与确认单。此次通过显式读取待测 Skill 文件执行，不能证明安装包自动加载。
- `cost_confirmation` 在当前服务端是兼容字段，不是服务端强制的费用上限；用户确认仍需在客户端执行。
- 待覆盖：参考媒体/数字人估价、确认后的提交与同键恢复、目标 MCP 移除旧工具后的兼容性、安装包自动加载。
