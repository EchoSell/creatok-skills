# WorkBuddy 新增工具评估

依据本地服务端 `lib/mcp/registry.ts` 与 contracts 静态快照；实际部署的 tools/list 和 schema 仍须在 WorkBuddy 测试环境核对。Shop Analytics 已纳入独立 Skill，Seller 店铺端到端验收待完成；角色替换复用总入口共享执行流程，发布及发现接入现有发布 Skill。角色替换已在 WorkBuddy 测试环境验证自然语言工具发现与真实估价，未提交生成；发布的 Content 视频已完成私密发布验收，Shop 分支待验收。

2026-11-11：WorkBuddy 发布只读探查新会话未发现测试 MCP 的任何可调用工具，未能查询账号、任务或趋势；没有实际发布、取消或生成。原因尚未证实，不能据此判断 TikTok 账号授权或接口不可用。测试 MCP 先前在其他会话实际可用，后续需复核连接与自动续期。

| 工具 | 决定与理由 |
|---|---|
| `creatok_tiktok_shop_live_minutes_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_live_products_list` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_lives_overview_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_lives_list` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_performance_hours_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_performance_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_product_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_products_list` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_sku_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_skus_list` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_sps_diagnosis_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_sps_metrics_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_sps_overview_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_sps_problems_list` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_sps_top_items_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_video_products_list` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_video_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_videos_overview_get` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_shop_videos_list` | 纳入 `creatok-shop-analytics`：按经营问题获取证据并生成分析报告；Seller 店铺端到端验收待完成。 |
| `creatok_tiktok_content_review_get` | 纳入 `creatok-tiktok-publishing`：发布后复盘内容及商品归因；缺失指标保留缺失。 |
| `creatok_tiktok_creator_video_get` | 纳入 `creatok-tiktok-publishing`：查询 Creator 视频表现；需账号权限、地区及 UTC 日期范围。 |
| `creatok_tiktok_affiliate_product_get` | 纳入 `creatok-tiktok-publishing`：在加入橱窗前查询联盟商品和佣金；需 Creator 授权。 |
| `creatok_tiktok_photo_destinations_list` | 纳入 `creatok-tiktok-publishing`：图文发布时选择可关联的店铺分类或集合。 |
| `creatok_tiktok_trending_hashtags_list` | 纳入 `creatok-tiktok-publishing`：按账号或指定地区查话题趋势；需有效 Pro，结果有缓存。 |
| `creatok_tiktok_trending_music_list` | 纳入 `creatok-tiktok-publishing`：按 Shop 市场查音乐趋势；需有效 Pro 和检查音乐可选状态。 |
| `creatok_tiktok_publish_tasks_list` | 纳入 `creatok-tiktok-publishing`：按条件浏览发布历史，已知任务恢复仍用状态查询。 |
| `creatok_tiktok_publish_prepare_cover` | 纳入 `creatok-tiktok-publishing`：发布前准备自定义封面，保留 cover_uri 与幂等键。 |
| `creatok_tiktok_showcase_sync_get` | 纳入 `creatok-tiktok-publishing`：跟踪橱窗添加后的同步与商品可发布状态，避免重复添加。 |
| `creatok_tiktok_publish_cancel` | 纳入 `creatok-tiktok-publishing`：用户明确要求时取消可取消的 Shop 发布任务；结果不明先查原任务。 |
| `creatok_content_analyze` | 纳入 creatok-analyze-video 和 creatok-recreate-video：统一内容分析及恢复。 |
| `creatok_character_replace` | 总入口直接调用：WorkBuddy 自行发现工具并完成测试素材验证、45 积分估价和确认前暂停；未生成，历史输入未能精确映射，任务恢复未验收。 |
| `creatok_account_get` | 总入口直接调用：按需读取账户快照。 |
| `creatok_feedback_submit` | 总入口直接调用：用户明确要求或确认后提交反馈。 |
