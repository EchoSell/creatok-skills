# WorkBuddy Shop Analytics 方案

## 目标和边界

新增一个面向经营问题的 `creatok-shop-analytics` Skill：基于当前 CreatOK MCP 的已授权 Seller 店铺数据，输出有证据、有优先级的经营诊断，而不是工具调用清单。它不接 KeyAPI、其他外部 MCP、公开竞品数据或 Web Agent 的专有图表运行时。普通 TikTok Creator 的内容表现及视频创意分析分别路由到现有发布与视频分析工作流，不冒充 Shop 卖家数据。

参考 Web Agent `creatok-analyze-account` 的结论先行、分维度证据和跨维综合；参考 `creatok-agent` 的 `docs/shop-analytics-skill-plan.md` 中结构、证据、判断的报告方法。两者含外部数据和专有渲染能力，本方案只借鉴方法，不假定这些数据或组件可用。

## 交互和报告

1. 确定用户目的（全店体检或商品、视频、直播、体验分专题）、店铺、统计日期和比较需求；发现可见且具备 Shop 数据能力的连接，多个店铺时展示名称供选择，不要求用户输入 ID。明确店铺当地时区，查询日期左闭右开；比较期应同长度且口径一致。
2. 全店体检先按需获取店铺表现及视频、商品、直播概览或排名；判断异常后再有限下钻，不默认请求全部 19 个工具。用户只问单项时按问题收窄。SPS 仅在地区、权限和服务支持时分析；返回限制时照实说明。
3. 输出：一句经营结论；核心指标与同期对比（若有）；商品、内容、直播、服务体验中有证据的关键发现；2–3 条按影响和可执行性排序的建议（每条标明依据、假设、下一步验证）；数据范围和缺口。按用户问题裁剪，不为凑章节伪造内容。
4. 可比较的数据才计算变化、贡献或占比：展示分子分母、币种、时间和样本；分母为零时不算增长率或比率。列表截断时明确仅覆盖已返回样本，不将头部样本当全店；金额/大 ID 保持精度。字段缺失、`missing_metrics`、`null`、`meta.stale` 和 `meta.refresh_failed` 明确披露，不写成零或新鲜数据。
5. 把观察、假设与建议区分开。可以说“高曝光低成交值得检查商品页/价格”，不能仅凭相关性断言原因；无成本不推利润、无广告花费不推 ROI、无留存/人群/市场数据不编造。先用自店、同口径比较，不引入虚构行业基准。仅在字段及口径支持时计算 GPM、集中度或转化漏斗，并解释其含义和限制。

## MCP 工具按工作流分组

- 店铺大盘：`creatok_tiktok_shop_performance_get`、`creatok_tiktok_shop_performance_hours_get`。
- 商品和规格：`creatok_tiktok_shop_products_list`、`creatok_tiktok_shop_product_get`、`creatok_tiktok_shop_skus_list`、`creatok_tiktok_shop_sku_get`。
- 内容：`creatok_tiktok_shop_videos_overview_get`、`creatok_tiktok_shop_videos_list`、`creatok_tiktok_shop_video_get`、`creatok_tiktok_shop_video_products_list`。
- 直播：`creatok_tiktok_shop_lives_overview_get`、`creatok_tiktok_shop_lives_list`、`creatok_tiktok_shop_live_products_list`、`creatok_tiktok_shop_live_minutes_get`。
- 店铺体验：`creatok_tiktok_shop_sps_overview_get`、`creatok_tiktok_shop_sps_metrics_get`、`creatok_tiktok_shop_sps_diagnosis_get`、`creatok_tiktok_shop_sps_problems_list`、`creatok_tiktok_shop_sps_top_items_get`。

额外使用连接发现和能力查询；按实际 schema 选择参数，保留服务返回的标识符和游标，不猜资源 ID。名称查询先用服务端支持的搜索/列表，出现多个候选时让用户选择；搜索或分页不完整时不声称全量。对无权限或无数据的维度继续交付可用部分，报告错误码及 request_id。

## 实施与验收

1. 先逐项核对 19 个工具输入、输出、比较期、时区、支持的维度及限制，设计具备缺失值、分页截断和过期元数据的测试数据；先写失败测试，检查路由、报告依据、错误处理与边界。
2. 实现 WorkBuddy Skill 与总入口路由、权限和校验；因仓库要求同步 Doubao 镜像，说明同步影响，不发布 Doubao 或 Codex。
3. 用完整、部分缺失、无权限和空数据样本验收报告质量：每条判断可追溯到返回字段，建议对应具体证据；核对不能计算的指标不会出现。执行仓库全量校验。
4. 使用已授权 Seller Shop 在 WorkBuddy 进行真实只读端到端验收：全店诊断及至少一个商品/视频专题，验证连接选择、日期、数据口径与报告。当前已检查的生产及测试工作区均无 Shop 连接，需找到有权限的工作区后才能完成此项；未验证项单列，不宣称全部通过。按功能原子提交，最后再决定发布 WorkBuddy。
