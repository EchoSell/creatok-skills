# WorkBuddy 账户查询验收

目标：在总入口按需调用测试环境 `creatok_account_get`，如实展示套餐、积分和数字人额度。

- 契约核对：空参数；`credits.remaining=null` 为不可读取；`subscription.access_until` 为包含宽限期的可用截止时间（Unix 秒）；`avatars.limit=0` 是实际零值；需注意 `meta.served_from_cache` 与 `meta.stale`。
- TDD：先对提交版本运行账户工作流断言，因未接入工具而失败；加入工具及上述规则后，`node scripts/test_account_workflow.mjs` 和 `npm test` 通过。断言仅检查 Skill 指令，不能证明模型对各种响应的行为。
- WorkBuddy 测试环境端到端调用：2026-11-10 在授权测试连接器后，WorkBuddy 以空参数调用 `creatok_account_get`，返回 `ok: true`，request ID 为 `mcp_req_49d7e884-604b-4f58-a2ac-6c3016d434bb`。回答展示了套餐、`access_until`、工作区积分、数字人配额及缓存状态，并依据 `access_until` 判断有效期；本次返回 `served_from_cache=false`、`stale=false`。
- 覆盖限制：本次显式要求读取临时目录中的 Skill 文件，未验证安装包自动加载或自然语言自动路由；实际返回没有覆盖积分空值、数字人零额度或过期缓存，尚未对这些情况做模拟行为测试。
