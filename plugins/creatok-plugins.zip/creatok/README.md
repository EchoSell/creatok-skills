# CreatOK plugin installation guide

This archive contains the CreatOK plugin, its Skills, and the production MCP configuration. Read this guide before installation. The instructions below are for Codex; Hermes, Claude Code, and other hosts have not yet been validated. Do not claim that this archive installs as a plugin in those hosts, or guess their configuration formats.

## Before making changes

1. Identify the host and check the installed CreatOK plugins, MCP connections, and CreatOK business Skills by their names and locations. Do not read or print credentials, tokens, or credential files. Distinguish the new plugin's connection from existing connections such as `creatok_direct`.
2. If existing CreatOK business Skills overlap with this plugin, show their paths and explain that shared Skill directories may be used by other agents. Ask the user to choose: **(1)** back up and move the identified overlapping Skills, then continue; **(2)** leave them in place and stop installation. Wait for the explicit answer before moving anything. Do not remove unrelated Skills, development/operations Skills, the CreatOK CLI, other plugins, or MCP connections.
3. If the user chooses backup, move only the identified overlapping Skill directories to a unique persistent backup directory outside all active Skill search paths. Record each original and backup path; never overwrite a backup. If identity, ownership, or safe restoration is uncertain, stop and ask. If the user declines or no answer is received, stop with all files unchanged. No conflict means no choice is needed. Do not move Skills already supplied by the plugin itself.

## Install on Codex

Install from a trusted, persistent Codex marketplace source using the supported `codex plugin marketplace add` and `codex plugin add` flow. `codex plugin add --help` and `codex plugin marketplace add --help` describe the installed CLI's supported arguments. The ZIP contains a plugin root, not a complete marketplace; do not claim unzipping alone registered it. For a local test, create a valid local marketplace in a persistent directory, register it, and install the `creatok` entry. Do not use a temporary directory that may disappear. Do not overwrite an existing marketplace or plugin with the same identity. If the host cannot register the package using supported mechanisms, report the actual blocker instead of using UI automation or editing internal application state.

For a local Codex test, unpack the archive into a persistent, user-owned directory so it contains `creatok/`. In that same directory create `.agents/plugins/marketplace.json` with a unique marketplace name and this structure (substitute a name that does not already exist):

```json
{"name":"creatok-local-test","plugins":[{"name":"creatok","source":{"source":"local","path":"./creatok"},"policy":{"installation":"AVAILABLE","authentication":"ON_INSTALL"},"category":"Productivity"}]}
```

Then run `codex plugin marketplace add <absolute-marketplace-directory>` and `codex plugin add creatok@creatok-local-test`, using the actual unique name. Inspect each command's result; do not report a connection as authorized just because installation succeeds. Keep the marketplace directory for future refresh or reinstall. This local marketplace method needs live host verification before it is offered as a production one-command installer.

The shared MCP configuration does not force a host-specific profile or client identity. Apply host-specific settings only when the host and service support them; do not infer or hardcode a tool count. Do not replace unrelated or custom MCP configuration.

## Connect and verify

Start the new plugin's own OAuth connection using the host-supported flow; guide the user to sign in and approve access in their browser. The user selects a CreatOK organization workspace only if the authorization page asks. Never ask for or display credentials or callback URLs. If authorization needs an action unavailable to the agent, describe the exact action rather than claiming success. Do not log into an existing same-named MCP connection as a substitute.

After authorization, start or reload a session if the host requires it. Discover the new plugin's actual MCP namespace and make a read-only call through that connection. Report separately: package installation, OAuth authorization, workspace if confirmed, and the new plugin's call result. An existing `creatok_direct` call, a cached tool listing, or a capabilities summary does not verify the new plugin connection or the total tool count. If the plugin connection cannot be distinguished or invoked, report verification as incomplete.
